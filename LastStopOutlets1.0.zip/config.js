// --- WEATHER CONSTANTS ---
const WEATHER_TYPES = [
    { name: "☀️ Clear", morale: 2, water: 0, farmMod: 1.0 },
    { name: "☁️ Cloudy", morale: 0, water: 0, farmMod: 1.0 },
    { name: "🌦️ Drizzle", morale: -1, water: 1, farmMod: 1.2 },
    { name: "🌧️ Rain", morale: -2, water: 2, farmMod: 1.5 },
    { name: "⛈️ Heavy Rain", morale: -3, water: 3, farmMod: 2.0 },
    { name: "🔥 Hot", morale: -1, water: -1, farmMod: 0.8 },
    { name: "🏜️ Very Hot", morale: -2, water: -2, farmMod: 0.5 },
    { name: "💨 Windy", morale: 0, water: 0, farmMod: 1.0 }
];

// --- BUILDING CONFIGURATION ---
const LEVEL_COSTS = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100];

const BUILDINGS = {
    livingQuarters: { 
        name: "🏠 Living Quarters", 
        level: 0, 
        desc: [
            "Sleeping Bags (Cap: 10)",
            "Wooden Bunks (Cap: 15)",
            "Partitioned Dorms (Cap: 20)",
            "Private Cubicles (Cap: 25)",
            "Luxury Suites (Cap: 30)"
        ]
    },
    farm: { 
        name: "🌽 Farm", 
        level: 0, 
        desc: [
            "Window Boxes (+2 Food)",
            "Rooftop Garden (+4 Food)",
            "Greenhouse (+6 Food)",
            "Hydroponics (+8 Food)",
            "Aeroponic Vertical Farm (+10 Food)"
        ]
    },
    waterColl: { 
        name: "💧 Water Collection", 
        level: 0, 
        desc: [
            "Roof Buckets (+2 Water)",
            "Rain Barrels (+4 Water)",
            "Dew Tarps (+6 Water)",
            "Gutter System (+8 Water)",
            "Filtration Tank (+10 Water)"
        ]
    },
    recRoom: { 
        name: "🎱 Rec Room", 
        level: 0, 
        desc: [
            "Deck of Cards (+1 Morale)",
            "Dart Board (+2 Morale)",
            "Pool Table (+3 Morale)",
            "Projector Screen (+4 Morale)",
            "Full Bar & Arcade (+5 Morale)"
        ]
    },
    watchtower: { 
        name: "🔭 Watchtower", 
        level: 0, 
        desc: [
            "Ladder to Roof (Risk -2%)",
            "Binoculars (Risk -4%)",
            "Sniper Nest (Risk -6%)",
            "Floodlights (Risk -8%)",
            "Drone Hub (Risk -10%)"
        ]
    },
    signage: { 
        name: "📡 Signage & Radio", 
        level: 0, 
        desc: [
            "Spraypaint on Wall (Recruit +)",
            "Wooden Billboards (Recruit ++)",
            "Ham Radio (Recruit +++)",
            "Shortwave Broadcast (Recruit ++++)",
            "Satellite Uplink (Recruit +++++)"
        ]
    },
    security: { 
        name: "🛡️ Security", 
        level: 0, 
        desc: [
            "Boarded Windows",
            "Reinforced Doors",
            "Barbed Wire Fence",
            "Perimeter Alarm",
            "Auto-Turrets"
        ]
    }
};

// --- JOB RISKS ---
const INJURY_CHANCE = {
    scavengeMall: 0.05,
    scavengeOut: 0.25,
    hunt: 0.15,
    water: 0.05,
    recruit: 0.20,
    medical: 0.0,
    rest: 0.0
};

// --- JOB YIELDS ---
const JOB_CONFIG = {
    mall: { minFood: 0, maxFood: 1, minWater: 0, maxWater: 1, minScrap: 2, maxScrap: 4, weaponChance: 0.05 },
    outside: { minFood: 0, maxFood: 1, minWater: 0, maxWater: 1, minScrap: 3, maxScrap: 7, weaponChance: 0.2, medicalChance: 0.15 },
    hunt: { minFood: 3, maxFood: 8, minWater: 0, maxWater: 1 },
    waterPerJob: 3,
    baseRecruitChance: 0.20,
    recruitBonusPerLevel: 0.10, 
    moraleRest: 2,
    
    // MEDICAL LOGIC
    medicBaseChance: 0.10,  // 10% chance without supplies
    medicBonusChance: 0.90  // 90% chance with supplies
};
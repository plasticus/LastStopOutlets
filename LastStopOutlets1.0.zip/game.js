// --- STATE MANAGEMENT ---

const JOBS = {
    scavengeMall: { name: "🛒 Scavenge (Mall)", count: 0 },
    scavengeOut: { name: "🏙️ Scavenge (Outside)", count: 0 },
    hunt: { name: "🏹 Hunt", count: 0 },
    water: { name: "🪣 Collect Water", count: 0 },
    medical: { name: "⚕️ Medical Care", count: 0 },
    recruit: { name: "🤝 Recruit", count: 0 },
    rest: { name: "💤 Rest", count: 0 }
};

const RES_ICONS = {
    food: "🥩",
    water: "💧",
    medical: "💊",
    scrap: "⚙️",
    weapons: "🔫",
    survivors: "👥"
};

let state = {
    day: 1,
    resources: {
        food: 20,
        water: 20,
        medical: 5,
        scrap: 10,
        weapons: 0,
        morale: 50,
        survivors: 5
    },
    dayStartResources: {}, 
    injured: 0,
    weather: WEATHER_TYPES[0],
    gameOver: false,
    logQueue: [] 
};

// --- INITIALIZATION ---
window.onload = function() {
    if (typeof JOB_CONFIG === 'undefined') {
        alert("Error: config.js not loaded!");
        return;
    }
    state.dayStartResources = { ...state.resources };
    renderUI();
    
    // Initial Narrative Log
    log("Welcome to Last Stop Outlets. Five survivors have banded together in this abandoned strip mall.", "flavor");
    log("Assign them jobs to gather resources. Winter is coming. Good luck.", "flavor");
    
    startDay();
};

// --- CORE LOOPS ---

function startDay() {
    if (state.gameOver) return;

    state.dayStartResources = { ...state.resources };

    state.weather = WEATHER_TYPES[Math.floor(Math.random() * WEATHER_TYPES.length)];
    
    let effectStr = "";
    if (state.weather.morale !== 0) {
        effectStr = `(Morale ${state.weather.morale > 0 ? '+' : ''}${state.weather.morale})`;
    }
    log(`🌤️ Weather: ${state.weather.name} ${effectStr}`, "weather");

    if (typeof FLAVOR_TEXT !== 'undefined' && FLAVOR_TEXT.length > 0) {
        const moodText = FLAVOR_TEXT[Math.floor(Math.random() * FLAVOR_TEXT.length)];
        log(moodText, "flavor");
    }

    renderUI();

    if (state.day > 1 && state.day % 2 === 0) {
        triggerEvent();
    }
}

function endDay() {
    if (state.gameOver) return;

    document.getElementById('end-day-btn').disabled = true;

    // 1. Process Day
    resolveJobs();
    resolveBuildings();

    state.resources.morale += state.weather.morale;
    state.resources.water += state.weather.water;

    const foodCons = state.resources.survivors;
    const waterCons = state.resources.survivors;
    
    state.resources.food -= foodCons;
    state.resources.water -= waterCons;
    
    log(`📉 Consumed ${foodCons} Food, ${waterCons} Water.`, "neutral");

    checkDeaths();

    // 2. Validate Assignments
    validateAssignments();

    // 3. Generate Summary
    let summaryParts = [];
    for (let key in state.resources) {
        let diff = state.resources[key] - state.dayStartResources[key];
        if (diff !== 0) {
            let sign = diff > 0 ? "+" : "";
            let capKey = key.charAt(0).toUpperCase() + key.slice(1);
            summaryParts.push(`${capKey} ${sign}${diff}`);
        }
    }

    // 4. Log Output
    log(`--- 🌙 End of Day ${state.day} ---`, "neutral"); 
    
    if (summaryParts.length > 0) {
        log(`📊 Day ${state.day} Summary: ${summaryParts.join(", ")}`, "neutral");
    } else {
        log(`📊 Day ${state.day} Summary: No changes.`, "neutral");
    }

    if (!state.gameOver) {
        if (state.day >= 30) {
            state.gameOver = true;
            log("🏆 DAY 30 REACHED. SURVIVAL SUCCESSFUL.", "good");
            triggerGameOver(true); // Win condition
        } else {
            state.day++;
            log(`📅 Day ${state.day} begins.`, "neutral");
            setTimeout(() => {
                startDay();
                document.getElementById('end-day-btn').disabled = false;
            }, 1500); 
        }
    }
    
    renderUI();
}

// --- LOGIC HELPERS ---

function validateAssignments() {
    let assigned = Object.values(JOBS).reduce((a, b) => a + b.count, 0);
    if (state.injured > state.resources.survivors) state.injured = state.resources.survivors;
    
    let available = state.resources.survivors - state.injured;

    if (assigned > available) {
        let toRemove = assigned - available;
        log(`⚠️ Work force shortage. ${toRemove} survivor(s) pulled from duties.`, "bad");

        let safety = 0;
        while (toRemove > 0 && safety < 100) {
            let jobKeys = Object.keys(JOBS);
            for (let i = jobKeys.length - 1; i >= 0; i--) {
                let key = jobKeys[i];
                if (JOBS[key].count > 0) {
                    JOBS[key].count--;
                    toRemove--;
                    break; 
                }
            }
            safety++;
        }
    }
}

function getRand(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getInjuryChance(jobType) {
    let base = INJURY_CHANCE[jobType] || 0;
    let reduction = BUILDINGS.watchtower.level * 0.02;
    return Math.max(0, base - reduction);
}

function rollForInjury(jobKey, count) {
    let injuries = 0;
    let chance = getInjuryChance(jobKey);
    
    for(let i=0; i<count; i++) {
        if (Math.random() < chance) injuries++;
    }
    return injuries;
}

// DYNAMIC YIELD CALCULATOR
function calculateYield(jobConfig, count) {
    let yields = { food: 0, water: 0, scrap: 0, weapons: 0, medical: 0 };
    
    for(let i=0; i<count; i++) {
        if (jobConfig.minFood !== undefined) yields.food += getRand(jobConfig.minFood, jobConfig.maxFood);
        if (jobConfig.minWater !== undefined) yields.water += getRand(jobConfig.minWater, jobConfig.maxWater);
        if (jobConfig.minScrap !== undefined) yields.scrap += getRand(jobConfig.minScrap, jobConfig.maxScrap);
        if (jobConfig.minMedical !== undefined) yields.medical += getRand(jobConfig.minMedical, jobConfig.maxMedical);
        
        if (jobConfig.weaponChance !== undefined && Math.random() < jobConfig.weaponChance) {
            yields.weapons++;
        }
        if (jobConfig.medicalChance !== undefined && Math.random() < jobConfig.medicalChance) {
            yields.medical++;
        }
    }
    return yields;
}

function formatYieldString(yields) {
    let parts = [];
    if (yields.food > 0) parts.push(`${yields.food} Food`);
    if (yields.water > 0) parts.push(`${yields.water} Water`);
    if (yields.scrap > 0) parts.push(`${yields.scrap} Scrap`);
    if (yields.weapons > 0) parts.push(`${yields.weapons} Weapons`);
    if (yields.medical > 0) parts.push(`${yields.medical} Meds`);
    return parts.join(", ");
}

function resolveJobs() {
    const j = JOBS;
    const cfg = JOB_CONFIG; 
    let totalInjuries = 0;

    // 1. Scavenge Mall
    if(j.scavengeMall.count > 0) {
        let res = calculateYield(cfg.mall, j.scavengeMall.count);
        
        state.resources.food += res.food;
        state.resources.water += res.water;
        state.resources.scrap += res.scrap;
        state.resources.weapons += res.weapons;
        state.resources.medical += res.medical;

        if (res.food + res.water + res.scrap + res.weapons + res.medical > 0) {
            log(`🛒 Mall team found: ${formatYieldString(res)}.`, "good");
        }
        totalInjuries += rollForInjury("scavengeMall", j.scavengeMall.count);
    }

    // 2. Scavenge Outside
    if(j.scavengeOut.count > 0) {
        let res = calculateYield(cfg.outside, j.scavengeOut.count);
        
        state.resources.food += res.food;
        state.resources.water += res.water;
        state.resources.scrap += res.scrap;
        state.resources.weapons += res.weapons;
        state.resources.medical += res.medical;

        if (res.food + res.water + res.scrap + res.weapons + res.medical > 0) {
            log(`🏙️ Outside Scavengers found: ${formatYieldString(res)}.`, "good");
        }
        totalInjuries += rollForInjury("scavengeOut", j.scavengeOut.count);
    }

    // 3. Hunt
    if(j.hunt.count > 0) {
        let res = calculateYield(cfg.hunt, j.hunt.count);
        
        state.resources.food += res.food;
        state.resources.water += res.water;
        state.resources.scrap += res.scrap;
        state.resources.weapons += res.weapons;
        state.resources.medical += res.medical;

        if (res.food + res.water + res.scrap + res.weapons + res.medical > 0) {
            log(`🏹 Hunters brought back: ${formatYieldString(res)}.`, "good");
        }
        totalInjuries += rollForInjury("hunt", j.hunt.count);
    }

    // 4. Water
    if(j.water.count > 0) {
        let w = j.water.count * cfg.waterPerJob;
        state.resources.water += w;
        log(`🪣 Collectors brought ${w} Water.`, "good");
        totalInjuries += rollForInjury("water", j.water.count);
    }

    // 5. Recruit
    for(let i=0; i<j.recruit.count; i++) {
        let chance = cfg.baseRecruitChance + (BUILDINGS.signage.level * cfg.recruitBonusPerLevel);
        if(Math.random() < chance) {
            state.resources.survivors++;
            log("👋 A survivor was recruited!", "good");
        }
        totalInjuries += rollForInjury("recruit", 1);
    }

    // 6. Rest
    if(j.rest.count > 0) {
        state.resources.morale += (j.rest.count * cfg.moraleRest);
    }
    
    // 7. Medical
    if(j.medical.count > 0 && state.injured > 0) {
        let healedCount = 0;
        let healedWithMeds = 0;
        let failedCount = 0;

        for (let i = 0; i < j.medical.count; i++) {
            if (state.injured <= 0) break;

            let chance = cfg.medicBaseChance; 
            let usedMed = false;

            if (state.resources.medical > 0) {
                state.resources.medical--;
                chance = cfg.medicBonusChance;
                usedMed = true;
            }

            if (Math.random() < chance) {
                state.injured--;
                healedCount++;
                if (usedMed) healedWithMeds++;
            } else {
                failedCount++;
            }
        }

        if (healedCount > 0 || failedCount > 0) {
            let parts = [];
            if (healedCount > 0) parts.push(`${healedCount} Healed (${healedWithMeds} w/ Supplies)`);
            if (failedCount > 0) parts.push(`${failedCount} Failed`);
            
            let type = healedCount > 0 ? "good" : "bad";
            log(`⚕️ Medical Report: ${parts.join(", ")}.`, type);
        }
    }

    // Apply Injuries
    if (totalInjuries > 0) {
        state.injured += totalInjuries;
        state.resources.morale -= (totalInjuries * 2);
        
        let verb = totalInjuries === 1 ? "was" : "were";
        let noun = totalInjuries === 1 ? "survivor" : "survivors";
        
        log(`🚑 ${totalInjuries} ${noun} ${verb} injured on the job!`, "bad");
    }
}

function resolveBuildings() {
    // Farm
    let farmFood = BUILDINGS.farm.level * 2 * state.weather.farmMod;
    farmFood = Math.floor(farmFood);
    if(farmFood > 0) {
        state.resources.food += farmFood;
        log(`🌽 Farm produced ${farmFood} Food.`, "good");
    }
    
    // Water
    let wCol = BUILDINGS.waterColl.level * 2;
    state.resources.water += wCol;

    // Rec Room
    if(BUILDINGS.recRoom && BUILDINGS.recRoom.level > 0) {
        let moraleBoost = BUILDINGS.recRoom.level * 1;
        state.resources.morale += moraleBoost;
        log(`🎱 Rec Room raised Morale by ${moraleBoost}.`, "good");
    }
}

function checkDeaths() {
    let deaths = 0;
    let desertions = 0;

    if (state.resources.food <= 0) deaths++;
    if (state.resources.water <= 0) deaths++;
    if (state.resources.food < 0) state.resources.food = 0;
    if (state.resources.water < 0) state.resources.water = 0;

    if (state.resources.morale <= 0) {
        desertions++;
        state.resources.morale = 0; 
    }

    if (deaths > 0) {
        state.resources.survivors -= deaths;
        state.resources.morale -= (10 * deaths);
        log(`💀 ${deaths} survivor(s) died from shortages.`, "bad");
    }

    if (desertions > 0) {
        state.resources.survivors -= desertions;
        state.resources.morale -= (5 * desertions);
        log(`🏃 ${desertions} survivor(s) deserted.`, "bad");
    }

    if (state.resources.survivors <= 0) {
        state.resources.survivors = 0;
        state.gameOver = true;
        log("☠️ COLONY COLLAPSED. GAME OVER.", "bad");
        triggerGameOver(false); // Loss condition
    }
}

function triggerGameOver(isWin) {
    const modal = document.getElementById('event-modal');
    document.getElementById('event-title').innerText = isWin ? "🏆 YOU SURVIVED!" : "☠️ COLONY COLLAPSED";
    document.getElementById('event-title').style.color = isWin ? "#00b894" : "#ff7675";

    let desc = isWin 
        ? "You made it to Day 30. Reinforcements have arrived." 
        : `Everyone is gone. You survived for ${state.day} days.`;
    
    document.getElementById('event-desc').innerText = desc;
    
    const choicesDiv = document.getElementById('event-choices');
    choicesDiv.innerHTML = '';

    const btn = document.createElement('button');
    btn.innerText = "Play Again (Reload)";
    btn.onclick = () => window.location.reload();
    choicesDiv.appendChild(btn);

    modal.classList.remove('hidden');
}

// --- EVENTS SYSTEM ---

function triggerEvent() {
    let stage = "early";
    if (state.day >= 9) stage = "mid";
    if (state.day >= 19) stage = "late";

    const possibleEvents = EVENT_DB.filter(e => e.stage === stage);
    if (possibleEvents.length === 0) return; 

    const event = possibleEvents[Math.floor(Math.random() * possibleEvents.length)];

    const modal = document.getElementById('event-modal');
    document.getElementById('event-title').innerText = "⚠️ " + event.title;
    document.getElementById('event-title').style.color = ""; // Reset color
    document.getElementById('event-desc').innerText = event.description;
    
    const choicesDiv = document.getElementById('event-choices');
    choicesDiv.innerHTML = '';

    event.choices.forEach(choice => {
        const btn = document.createElement('button');
        btn.innerText = choice.text;
        
        let canAfford = true;
        for (let key in choice.effect) {
            // FIX: DO NOT Check affordability for Morale or Survivors penalties.
            // You can always choose to take a morale hit or death.
            if (key === 'morale' || key === 'survivors') continue;

            if (choice.effect[key] < 0) {
                let cost = Math.abs(choice.effect[key]);
                if (state.resources[key] < cost) {
                    canAfford = false;
                }
            }
        }

        if (!canAfford) {
            btn.disabled = true;
            btn.innerText += " (Missing Resources)";
            btn.style.opacity = "0.5";
            btn.style.cursor = "not-allowed";
        } else {
            btn.onclick = () => {
                applyEventEffect(choice.effect, choice.text, event.title);
                modal.classList.add('hidden');
            };
        }
        
        choicesDiv.appendChild(btn);
    });

    modal.classList.remove('hidden');
}

function applyEventEffect(effect, choiceText, eventTitle) {
    let summary = [];

    for (let key in effect) {
        if(state.resources.hasOwnProperty(key)) {
            state.resources[key] += effect[key];
            
            // Allow Morale to drop to 0, but not strictly bound checks for other things here
            if (state.resources[key] < 0) state.resources[key] = 0;

            let sign = effect[key] > 0 ? "+" : "";
            let capKey = key.charAt(0).toUpperCase() + key.slice(1);
            summary.push(`${sign}${effect[key]} ${capKey}`);
        }
    }
    
    let resultStr = summary.length > 0 ? `(Result: ${summary.join(', ')})` : "(No effect)";
    log(`Event - ${eventTitle}, Choice: ${choiceText} ${resultStr}`, "neutral");
    
    renderUI();
}

// --- UI & LOGGING ---

function log(msg, type) {
    state.logQueue.push({ msg, type });
    processLogQueue();
}

let isProcessingLog = false;
function processLogQueue() {
    if (isProcessingLog || state.logQueue.length === 0) return;

    isProcessingLog = true;
    const item = state.logQueue.shift();
    
    const logPanel = document.getElementById('log-output');
    const div = document.createElement('div');
    div.className = `log-line log-${item.type}`;
    div.innerText = item.msg; 
    
    logPanel.prepend(div);
    logPanel.scrollTop = 0;

    setTimeout(() => {
        isProcessingLog = false;
        processLogQueue();
    }, 500); 
}

function getMoraleEmoji(val) {
    if (val >= 75) return "🤩";
    if (val >= 50) return "🙂";
    if (val >= 25) return "😐";
    if (val > 0) return "😨";
    return "💀";
}

function renderUI() {
    document.getElementById('day-display').innerText = `📅 Day ${state.day}`;
    document.getElementById('weather-display').innerText = state.weather.name;

    const resDiv = document.getElementById('resource-bar');
    resDiv.innerHTML = '';
    
    for(let [key, val] of Object.entries(state.resources)) {
        let icon = RES_ICONS[key];
        if (key === 'morale') icon = getMoraleEmoji(val);
        if (!icon && key === 'morale') icon = "😐";

        resDiv.innerHTML += `
            <div class="res-card">
                <span>${icon || ''} ${val}</span>
                <label>${key}</label>
            </div>
        `;
    }

    resDiv.innerHTML += `
        <div class="res-card" style="border: 1px solid #ff7675;">
            <span style="color:#ff7675">🚑 ${state.injured}</span>
            <label style="color:#ff7675">INJURED</label>
        </div>
    `;

    const buildDiv = document.getElementById('building-list');
    buildDiv.innerHTML = '';
    for(let [key, b] of Object.entries(BUILDINGS)) {
        let costIndex = b.level;
        let currentCost = LEVEL_COSTS[costIndex] || 100;

        const canAfford = state.resources.scrap >= currentCost;
        
        let descText = "";
        if (b.level === 0) {
            descText = "Not Constructed";
        } else if (Array.isArray(b.desc)) {
            let descIndex = b.level - 1;
            if (descIndex >= b.desc.length) descIndex = b.desc.length - 1;
            descText = b.desc[descIndex];
        } else {
            descText = b.desc;
        }

        buildDiv.innerHTML += `
            <div class="list-item">
                <div>
                    <strong>${b.name} <span style="color:#6c5ce7">(Lvl ${b.level})</span></strong><br>
                    <small style="color:#888">${descText}</small>
                </div>
                <button ${canAfford ? '' : 'disabled'} onclick="upgradeBuilding('${key}')">
                    🔼 (${currentCost} ⚙️)
                </button>
            </div>
        `;
    }

    const jobDiv = document.getElementById('job-list');
    jobDiv.innerHTML = '';
    let assignedTotal = Object.values(JOBS).reduce((a, b) => a + b.count, 0);
    const unassigned = state.resources.survivors - state.injured - assignedTotal;
    
    const unassignedSpan = document.getElementById('unassigned-count');
    unassignedSpan.innerText = unassigned;
    unassignedSpan.style.color = unassigned > 0 ? '#00b894' : (unassigned === 0 ? '#666' : 'red');
    
    const endDayBtn = document.getElementById('end-day-btn');
    if (unassigned < 0) {
        endDayBtn.disabled = true;
        endDayBtn.innerText = "OVER ASSIGNED!";
        endDayBtn.style.background = "#555";
    } else if (!state.gameOver) {
        if (endDayBtn.innerText === "OVER ASSIGNED!") {
             endDayBtn.disabled = false;
             endDayBtn.innerText = "END DAY";
             endDayBtn.style.background = ""; 
        }
    }

    for(let [key, j] of Object.entries(JOBS)) {
        jobDiv.innerHTML += `
            <div class="list-item">
                <span>${j.name}</span>
                <div class="control-group">
                    <button onclick="assignJob('${key}', -1)">-</button>
                    <span>${j.count}</span>
                    <button onclick="assignJob('${key}', 1)">+</button>
                </div>
            </div>
        `;
    }
}

// --- ACTIONS ---

window.assignJob = function(jobKey, amount) {
    if (state.gameOver) return;
    
    const job = JOBS[jobKey];
    let assignedTotal = Object.values(JOBS).reduce((a, b) => a + b.count, 0);
    const unassigned = state.resources.survivors - state.injured - assignedTotal;

    if (amount > 0 && unassigned > 0) {
        job.count++;
    } else if (amount < 0 && job.count > 0) {
        job.count--;
    }
    renderUI();
};

window.upgradeBuilding = function(key) {
    if (state.gameOver) return;
    
    const b = BUILDINGS[key];
    let costIndex = b.level;
    let currentCost = LEVEL_COSTS[costIndex] || 100;

    if (state.resources.scrap >= currentCost) {
        state.resources.scrap -= currentCost;
        b.level++;
        log(`🔨 Upgraded ${b.name} to Level ${b.level}`, "good");
        renderUI();
    }
};